    </div> 
    <footer style="text-align:center; padding:15px 0; background:#f5f5f5; border-top:1px solid #ddd; margin-top:30px;">
        &copy; <?= date('Y') ?> E-Dokumen | Dibuat oleh Zhafran
    </footer>
</body>
</html>
