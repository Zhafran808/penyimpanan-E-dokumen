<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>E-Dokumen</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="navbar">
        <div class="navbar-left">
            <span class="logo">📄 E-Dokumen</span>
            <a href="dashboard.php">Dashboard</a>
            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                <a href="admin/panel.php">Admin Panel</a>
            <?php endif; ?>
        </div>
        <div class="navbar-right">
            <?php if (isset($_SESSION['user_id'])): ?>
                <span class="user-info">
                    <?= htmlspecialchars($_SESSION['role']) ?>
                </span>
                <a href="logout.php">Logout</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="container">
