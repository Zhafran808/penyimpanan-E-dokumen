<?php
$host     = "localhost";
$user     = "root";        
$password = "11269";            
$database = "e_dokumen";   

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
