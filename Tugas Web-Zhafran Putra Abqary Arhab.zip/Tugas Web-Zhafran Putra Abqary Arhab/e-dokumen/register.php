<?php
include 'includes/koneksi.php';

$pesan = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username     = mysqli_real_escape_string($conn, $_POST['username']);
    $password     = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $nama_lengkap = mysqli_real_escape_string($conn, $_POST['nama_lengkap']);
    $email        = mysqli_real_escape_string($conn, $_POST['email']);

    $cek = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");
    if (mysqli_num_rows($cek) > 0) {
        $pesan = "Username sudah digunakan!";
    } else {
        $query = "INSERT INTO users (username, password, nama_lengkap, email, role)
                  VALUES ('$username', '$password', '$nama_lengkap', '$email', 'user')";
        if (mysqli_query($conn, $query)) {
            $pesan = "Registrasi berhasil! Silakan login.";
        } else {
            $pesan = "Gagal registrasi: " . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrasi Akun</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="form-center">
        <h2>Form Registrasi</h2>
        <form method="post" action="">
            <label>Nama Lengkap</label>
            <input type="text" name="nama_lengkap" required>
            <label>Username</label>
            <input type="text" name="username" required>
            <label>Email</label>
            <input type="email" name="email">
            <label>Password</label>
            <div style="position:relative;width:100%;">
                <input type="password" name="password" id="password" required style="padding-right:44px;width:100%;">
                <span onclick="togglePassword()" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);cursor:pointer;">
                    <img id="eyeIcon" src="assets/img/eye.png" alt="Show" width="22" height="22" style="display:block;">
                </span>
            </div>
            <button type="submit">Daftar</button>
        </form>
        <p><?php echo $pesan; ?></p>
        <p>Sudah punya akun? <a href="index.php">Login di sini</a></p>
    </div>
    <script>
    function togglePassword() {
        var pwd = document.getElementById('password');
        var icon = document.getElementById('eyeIcon');
        if (pwd.type === 'password') {
            pwd.type = 'text';
            icon.src = 'assets/img/eye-slash.png';
            icon.alt = 'Hide';
        } else {
            pwd.type = 'password';
            icon.src = 'assets/img/eye.png';
            icon.alt = 'Show';
        }
    }
    </script>
</body>
</html>
