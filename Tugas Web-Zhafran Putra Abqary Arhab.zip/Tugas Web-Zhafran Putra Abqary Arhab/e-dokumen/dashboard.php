<?php
session_start();
require_once 'includes/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt2 = $conn->prepare("SELECT * FROM dokumen WHERE diupload_oleh = ? ORDER BY uploaded_at DESC");
$stmt2->bind_param("i", $user_id);
$stmt2->execute();
$result2 = $stmt2->get_result();
$dokumen = [];
while ($row = $result2->fetch_assoc()) {
    $dokumen[] = $row;
}

$jumlah_dokumen = count($dokumen);
$last_upload = $jumlah_dokumen > 0 ? $dokumen[0]['uploaded_at'] : '-';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hapus_id'])) {
    $hapus_id = intval($_POST['hapus_id']);

    $cek = $conn->prepare("SELECT nama_file FROM dokumen WHERE id = ? AND diupload_oleh = ?");
    $cek->bind_param("ii", $hapus_id, $user_id);
    $cek->execute();
    $res = $cek->get_result();
    if ($row = $res->fetch_assoc()) {

        if (file_exists($row['nama_file'])) {
            unlink($row['nama_file']);
        }

        $del = $conn->prepare("DELETE FROM dokumen WHERE id = ? AND diupload_oleh = ?");
        $del->bind_param("ii", $hapus_id, $user_id);
        $del->execute();

        header("Location: dashboard.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard User</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/script.js"></script>
</head>
<body>
    <div class="navbar">
        <div class="navbar-left">
            <span class="logo">📄 E-Dokumen</span>
            <a href="dashboard.php" class="active">Dashboard</a>
        </div>
        <div class="navbar-right">
            <span class="user-info"><?= htmlspecialchars($user['nama_lengkap']) ?></span>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    <div class="container">
        <div class="dashboard-header">
            <div class="avatar-circle"><?= strtoupper(substr($user['nama_lengkap'],0,1)) ?></div>
            <div>
                <h2 style="margin-bottom:4px;">Halo, <?= htmlspecialchars($user['nama_lengkap']) ?></h2>
                <div class="user-email"><?= htmlspecialchars($user['email']) ?></div>
            </div>
        </div>
        <div class="dashboard-stats">
            <div class="stat-box">
                <div class="stat-title">Total Dokumen</div>
                <div class="stat-value"><?= $jumlah_dokumen ?></div>
            </div>
            <div class="stat-box">
                <div class="stat-title">Upload Terakhir</div>
                <div class="stat-value"><?= $last_upload ?></div>
            </div>
        </div>
        <div style="text-align:right;margin-bottom:18px;">
            <a href="upload.php" class="btn-utama">+ Upload Dokumen</a>
        </div>
        <h3>Dokumen Anda</h3>
        <table>
            <tr>
                <th>Judul</th>
                <th>Kategori</th>
                <th>Deskripsi</th>
                <th>Waktu Upload</th>
                <th>Aksi</th>
            </tr>
            <?php foreach ($dokumen as $d): ?>
            <tr>
                <td><?= htmlspecialchars($d['judul']) ?></td>
                <td><?= htmlspecialchars($d['kategori']) ?></td>
                <td><?= htmlspecialchars($d['deskripsi']) ?></td>
                <td><?= $d['uploaded_at'] ?></td>
                <td>
                    <a href="detail.php?id=<?= $d['id'] ?>" class="btn-table">Detail</a>
                    <a href="download.php?id=<?= $d['id'] ?>" class="btn-table btn-download">Download</a>
                    <form method="post" action="" style="display:inline;">
                        <input type="hidden" name="hapus_id" value="<?= $d['id'] ?>">
                        <button type="submit" class="btn-table btn-delete" onclick="return confirm('Yakin ingin menghapus dokumen ini?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if (count($dokumen) === 0): ?>
            <tr><td colspan="5" style="text-align:center;">Belum ada dokumen.</td></tr>
            <?php endif; ?>
        </table>
    </div>
    <footer>
        &copy; <?= date('Y') ?> E-Dokumen | Dibuat oleh Zhafran
    </footer>
</body>
</html>
