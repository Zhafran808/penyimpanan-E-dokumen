<?php
session_start();
require_once 'includes/koneksi.php';

$search = isset($_GET['q']) ? mysqli_real_escape_string($conn, $_GET['q']) : '';
$where = $search ? "WHERE judul LIKE '%$search%' OR kategori LIKE '%$search%'" : '';
$query = "SELECT d.*, u.nama_lengkap FROM dokumen d LEFT JOIN users u ON d.diupload_oleh = u.id $where ORDER BY d.uploaded_at DESC LIMIT 5";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Beranda | E-Dokumen</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/script.js"></script>
</head>
<body>
    <div class="navbar">
        <div class="navbar-left">
            <span class="logo">📄 E-Dokumen</span>
            <a href="index.php" class="active">Home</a>
        </div>
        <div class="navbar-right">
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        </div>
    </div>
    <div class="container">
        <h2>Selamat Datang di E-Dokumen</h2>
        <form method="get" class="search-form">
            <input type="text" name="q" placeholder="Cari dokumen (judul/kategori)..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit">Cari</button>
        </form>
        <h3>Dokumen Publik Terbaru</h3>
        <table>
            <tr>
                <th>Judul</th>
                <th>Kategori</th>
                <th>Uploader</th>
                <th>Waktu</th>
                <th>Preview</th>
            </tr>
            <?php while ($d = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?= htmlspecialchars($d['judul']) ?></td>
                <td><?= htmlspecialchars($d['kategori']) ?></td>
                <td><?= htmlspecialchars($d['nama_lengkap']) ?></td>
                <td><?= $d['uploaded_at'] ?></td>
                <td>
                    <a href="detail.php?id=<?= $d['id'] ?>">Lihat</a>
                </td>
            </tr>
            <?php endwhile; ?>
            <?php if (mysqli_num_rows($result) === 0): ?>
            <tr><td colspan="5">Belum ada dokumen.</td></tr>
            <?php endif; ?>
        </table>
        <div style="text-align:center;margin:32px 0;">
            <a href="login.php" class="btn-utama" style="padding:12px 32px;font-size:1.1em;">Login untuk Upload</a>
        </div>
        <div class="about-row">
            <div class="about-col">
                <h3>Visi & Misi</h3>
                <ul class="visi-misi">
                    <li>Membuka akses pengetahuan untuk semua kalangan.</li>
                    <li>Memudahkan pencarian dan berbagi dokumen digital.</li>
                    <li>Mendukung budaya literasi digital di Indonesia.</li>
                </ul>
            </div>
            <div class="about-col">
                <h3>Tentang E-Dokumen</h3>
                <p>
                    E-Dokumen adalah platform penyimpanan dan berbagi dokumen digital yang mudah diakses kapan saja dan di mana saja.<br>
                    <b>30 hari pertama gratis</b> untuk pengguna baru. Setelah itu, biaya langganan tetap terjangkau.<br>
                    <span style="color:#2563eb;">Ayo mulai perjalanan literasi digitalmu bersama kami!</span>
                </p>
            </div>
        </div>
    </div>
    <footer>
        &copy; <?= date('Y') ?> E-Dokumen | Dibuat oleh Zhafran
    </footer>
</body>
</html>
