<?php
session_start();
require_once '../includes/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $q = mysqli_query($conn, "SELECT nama_file FROM dokumen WHERE id=$id");
    $f = mysqli_fetch_assoc($q);
    if ($f) {
        if (file_exists("../" . $f['nama_file'])) {
            unlink("../" . $f['nama_file']);
        }
        mysqli_query($conn, "DELETE FROM dokumen WHERE id=$id");
    }
    header('Location: kelola_dokumen.php');
    exit;
}

$result = mysqli_query($conn, "SELECT d.*, u.nama_lengkap FROM dokumen d LEFT JOIN users u ON d.diupload_oleh = u.id ORDER BY d.uploaded_at DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Kelola Dokumen</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="../assets/js/script.js"></script>
</head>
<body>
    <div class="navbar admin-navbar">
        <div class="navbar-left">
            <span class="logo">👑 Admin E-Dokumen</span>
            <a href="panel.php">Panel</a>
            <a href="kelola_user.php">Kelola User</a>
            <a href="kelola_dokumen.php" class="active">Kelola Dokumen</a>
        </div>
        <div class="navbar-right">
            <a href="../logout.php">Logout</a>
        </div>
    </div>
    <div class="admin-container">
        <h2>Kelola Dokumen</h2>
        <table>
            <tr>
                <th>No</th>
                <th>Judul</th>
                <th>Kategori</th>
                <th>Deskripsi</th>
                <th>Nama File</th>
                <th>Uploader</th>
                <th>Waktu Upload</th>
                <th>Aksi</th>
            </tr>
            <?php $no=1; while ($dok = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($dok['judul']) ?></td>
                <td><?= htmlspecialchars($dok['kategori']) ?></td>
                <td><?= htmlspecialchars($dok['deskripsi']) ?></td>
                <td><?= htmlspecialchars(basename($dok['nama_file'])) ?></td>
                <td><?= htmlspecialchars($dok['nama_lengkap']) ?></td>
                <td><?= $dok['uploaded_at'] ?></td>
                <td>
                    <a href="../download.php?id=<?= $dok['id'] ?>" class="btn-table btn-download">Download</a>
                    <a href="?hapus=<?= $dok['id'] ?>" class="btn-table btn-delete confirm-delete">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
            <?php if (mysqli_num_rows($result) === 0): ?>
            <tr><td colspan="8" style="text-align:center;">Tidak ada dokumen.</td></tr>
            <?php endif; ?>
        </table>
    </div>
    <footer>
        &copy; <?= date('Y') ?> E-Dokumen | Panel Admin
    </footer>
</body>
</html>
