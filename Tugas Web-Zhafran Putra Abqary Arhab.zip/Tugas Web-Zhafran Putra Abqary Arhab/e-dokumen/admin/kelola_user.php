<?php
session_start();
require_once '../includes/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $cek = mysqli_query($conn, "SELECT * FROM users WHERE id=$id AND role='user'");
    if (mysqli_num_rows($cek) > 0) {
        mysqli_query($conn, "DELETE FROM users WHERE id=$id");
    }
    header('Location: kelola_user.php');
    exit;
}

$result = mysqli_query($conn, "SELECT * FROM users WHERE role='user' ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Kelola User</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="../assets/js/script.js"></script>
</head>
<body>
    <div class="navbar admin-navbar">
        <div class="navbar-left">
            <span class="logo">👑 Admin E-Dokumen</span>
            <a href="panel.php">Panel</a>
            <a href="kelola_user.php" class="active">Kelola User</a>
            <a href="kelola_dokumen.php">Kelola Dokumen</a>
        </div>
        <div class="navbar-right">
            <a href="../logout.php">Logout</a>
        </div>
    </div>
    <div class="admin-container">
        <h2>Kelola User</h2>
        <table>
            <tr>
                <th>No</th>
                <th>Nama Lengkap</th>
                <th>Username</th>
                <th>Email</th>
                <th>Terdaftar</th>
                <th>Aksi</th>
            </tr>
            <?php $no=1; while ($user = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($user['nama_lengkap']) ?></td>
                <td><?= htmlspecialchars($user['username']) ?></td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td><?= $user['created_at'] ?></td>
                <td>
                    <a href="?hapus=<?= $user['id'] ?>" class="btn-table btn-delete confirm-delete">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
            <?php if (mysqli_num_rows($result) === 0): ?>
            <tr><td colspan="6" style="text-align:center;">Tidak ada user.</td></tr>
            <?php endif; ?>
        </table>
    </div>
    <footer>
        &copy; <?= date('Y') ?> E-Dokumen | Panel Admin
    </footer>
</body>
</html>
