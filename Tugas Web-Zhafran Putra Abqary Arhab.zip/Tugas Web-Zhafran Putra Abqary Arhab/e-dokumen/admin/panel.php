<?php
session_start();
require_once '../includes/koneksi.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();

$resultUser = mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE role='user'");
$userCount = mysqli_fetch_assoc($resultUser)['total'];

$resultDok = mysqli_query($conn, "SELECT COUNT(*) as total FROM dokumen");
$dokumenCount = mysqli_fetch_assoc($resultDok)['total'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="../assets/js/script.js"></script>
</head>
<body>
    <div class="navbar admin-navbar">
        <div class="navbar-left">
            <span class="logo">👑 Admin E-Dokumen</span>
            <a href="panel.php" class="active">Panel</a>
            <a href="kelola_user.php">Kelola User</a>
            <a href="kelola_dokumen.php">Kelola Dokumen</a>
        </div>
        <div class="navbar-right">
            <span class="admin-avatar"><?= strtoupper(substr($admin['nama_lengkap'],0,1)) ?></span>
            <span class="admin-info"><?= htmlspecialchars($admin['nama_lengkap']) ?> (Admin)</span>
            <a href="../logout.php">Logout</a>
        </div>
    </div>
    <div class="admin-container">
        <h2 style="margin-bottom:8px;">Selamat Datang, <?= htmlspecialchars($admin['nama_lengkap']) ?></h2>
        <div class="admin-stats-row">
            <div class="admin-stat-card">
                <div class="admin-stat-icon user">
                    <svg width="32" height="32" fill="none" viewBox="0 0 32 32"><circle cx="16" cy="16" r="16" fill="#2563eb"/><path d="M16 16a5 5 0 1 0 0-10 5 5 0 0 0 0 10Zm0 2c-4.418 0-8 2.015-8 4.5V25h16v-2.5c0-2.485-3.582-4.5-8-4.5Z" fill="#fff"/></svg>
                </div>
                <div class="admin-stat-title">Total User</div>
                <div class="admin-stat-value"><?= $userCount ?></div>
            </div>
            <div class="admin-stat-card">
                <div class="admin-stat-icon dokumen">
                    <svg width="32" height="32" fill="none" viewBox="0 0 32 32"><rect width="32" height="32" rx="16" fill="#22c55e"/><path d="M10 9a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-8a2 2 0 0 1-2-2V9Zm2 0v14h8V9h-8Zm2 4h4v2h-4v-2Z" fill="#fff"/></svg>
                </div>
                <div class="admin-stat-title">Total Dokumen</div>
                <div class="admin-stat-value"><?= $dokumenCount ?></div>
            </div>
        </div>
        <div class="admin-menu-row">
            <a href="kelola_user.php" class="admin-menu-card">
                <div class="menu-icon user">
                    <svg width="28" height="28" fill="none" viewBox="0 0 32 32"><circle cx="16" cy="16" r="16" fill="#2563eb"/><path d="M16 16a5 5 0 1 0 0-10 5 5 0 0 0 0 10Zm0 2c-4.418 0-8 2.015-8 4.5V25h16v-2.5c0-2.485-3.582-4.5-8-4.5Z" fill="#fff"/></svg>
                </div>
                <div class="menu-title">Kelola User</div>
                <div class="menu-desc">Lihat, tambah, atau hapus user</div>
            </a>
            <a href="kelola_dokumen.php" class="admin-menu-card">
                <div class="menu-icon dokumen">
                    <svg width="28" height="28" fill="none" viewBox="0 0 32 32"><rect width="32" height="32" rx="16" fill="#22c55e"/><path d="M10 9a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-8a2 2 0 0 1-2-2V9Zm2 0v14h8V9h-8Zm2 4h4v2h-4v-2Z" fill="#fff"/></svg>
                </div>
                <div class="menu-title">Kelola Dokumen</div>
                <div class="menu-desc">Lihat, download, atau hapus dokumen</div>
            </a>
        </div>
    </div>
    <footer style="margin-top:40px;padding:18px 0 12px 0;text-align:center;background:#f3f6fa;border-top:1.5px solid #e5e7eb;">
        &copy; <?= date('Y') ?> E-Dokumen | Panel Admin
    </footer>
</body>
</html>
