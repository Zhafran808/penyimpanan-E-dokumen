<?php
session_start();
require_once 'includes/koneksi.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$stmt = $conn->prepare("SELECT d.*, u.nama_lengkap FROM dokumen d JOIN users u ON d.diupload_oleh = u.id WHERE d.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$dokumen = $result->fetch_assoc();

if (!$dokumen) {
    echo "<div style='padding:40px;text-align:center;color:#dc2626;font-size:1.2em;'>Dokumen tidak ditemukan.</div>";
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Detail Dokumen</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="navbar">
        <div class="navbar-left">
            <span class="logo">📄 E-Dokumen</span>
            <a href="dashboard.php">Dashboard</a>
        </div>
        <div class="navbar-right">
            <a href="logout.php">Logout</a>
        </div>
    </div>
    <div class="container" style="max-width:520px;margin-top:40px;">
        <div style="text-align:center;margin-bottom:18px;">
            <img src="assets/img/pdf-icon.png" alt="PDF" width="54" height="54" style="margin-bottom:8px;">
            <h2 style="margin-bottom:2px;"><?= htmlspecialchars($dokumen['judul']) ?></h2>
            <div style="color:#64748b;font-size:1.05em;margin-bottom:10px;">
                Kategori: <?= htmlspecialchars($dokumen['kategori']) ?>
            </div>
        </div>
        <table style="margin-bottom:18px;">
            <tr><td style="width:120px;">Deskripsi</td><td>: <?= htmlspecialchars($dokumen['deskripsi']) ?: '<span style="color:#aaa;">(Tidak ada deskripsi)</span>' ?></td></tr>
            <tr><td>Nama File</td><td>: <?= htmlspecialchars(basename($dokumen['nama_file'])) ?></td></tr>
            <tr><td>Diupload Oleh</td><td>: <?= htmlspecialchars($dokumen['nama_lengkap']) ?></td></tr>
            <tr><td>Waktu Upload</td><td>: <?= $dokumen['uploaded_at'] ?></td></tr>
        </table>
        <div style="text-align:center;">
            <a href="download.php?id=<?= $dokumen['id'] ?>" class="btn-utama" style="padding:10px 32px;">Download File</a>
        </div>
        <div style="margin-top:18px;text-align:center;">
            <a href="dashboard.php" style="color:#2563eb;text-decoration:underline;">&#8592; Kembali ke Dashboard</a>
        </div>
    </div>
    <footer>
        &copy; <?= date('Y') ?> E-Dokumen
    </footer>
</body>
</html>
