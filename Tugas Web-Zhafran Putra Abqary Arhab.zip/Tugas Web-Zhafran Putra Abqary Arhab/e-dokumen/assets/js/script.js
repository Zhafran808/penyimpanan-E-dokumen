document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.toggle-password').forEach(function(toggle) {
        toggle.addEventListener('click', function() {
            const input = this.parentElement.querySelector('input[type="password"], input[type="text"]');
            const icon = this.querySelector('img');
            if (input.type === 'password') {
                input.type = 'text';
                icon.src = 'assets/img/eye-slash.png';
                icon.alt = 'Hide';
            } else {
                input.type = 'password';
                icon.src = 'assets/img/eye.png';
                icon.alt = 'Show';
            }
        });
    });
});

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('table tr').forEach(function(row) {
        row.addEventListener('mouseenter', function() {
            this.style.background = '#e0e7ef';
        });
        row.addEventListener('mouseleave', function() {
            this.style.background = '';
        });
    });
});

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.confirm-delete').forEach(function(link) {
        link.addEventListener('click', function(e) {
            if (!confirm('Yakin ingin menghapus data ini?')) {
                e.preventDefault();
            }
        });
    });
});

document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        document.querySelectorAll('.success, .error').forEach(function(el) {
            el.style.transition = 'opacity 0.5s';
            el.style.opacity = 0;
            setTimeout(function() { el.style.display = 'none'; }, 500);
        });
    }, 3000);
});

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.btn-table').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            btn.classList.add('clicked');
            setTimeout(function() {
                btn.classList.remove('clicked');
            }, 300);
        });
    });
});

