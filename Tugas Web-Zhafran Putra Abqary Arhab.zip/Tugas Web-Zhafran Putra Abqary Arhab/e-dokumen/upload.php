<?php
session_start();
require_once 'includes/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header('Location: index.php');
    exit;
}

$pesan = '';
$success = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);
    $user_id = $_SESSION['user_id'];

    $target_dir = "uploads/";
    $nama_file = basename($_FILES["file"]["name"]);
    $target_file = $target_dir . time() . '_' . $nama_file;
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        $stmt = $conn->prepare("INSERT INTO dokumen (judul, nama_file, deskripsi, kategori, diupload_oleh) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssi", $judul, $target_file, $deskripsi, $kategori, $user_id);
        if ($stmt->execute()) {
            $pesan = "Dokumen berhasil diupload!";
            $success = true;
        } else {
            $pesan = "Gagal upload dokumen: " . $conn->error;
        }
    } else {
        $pesan = "Gagal upload file.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Upload Dokumen</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/script.js"></script>
    <style>
    .form-center {
        max-width: 350px !important;
        padding: 18px 18px 24px 18px !important;
        font-size: 0.97em !important;
    }
    .form-center input[type="text"],
    .form-center textarea,
    .form-center .file-input-wrapper {
        max-width: 320px !important;
        font-size: 0.97em !important;
        padding: 6px 8px !important;
    }
    .btn-utama {
        font-size: 0.97em !important;
        padding: 8px 0 !important;
        max-width: 320px !important;
    }
    .upload-icon svg {
        width: 36px !important;
        height: 36px !important;
    }
    .custom-file-label {
        font-size: 0.97em !important;
        padding: 6px 8px !important;
    }
    .file-name-preview {
        font-size: 0.95em !important;
    }
    h2 {
        font-size: 1.2em !important;
    }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="navbar-left">
            <span class="logo">📄 E-Dokumen</span>
            <a href="dashboard.php">Dashboard</a>
        </div>
        <div class="navbar-right">
            <a href="logout.php">Logout</a>
        </div>
    </div>
    <div class="form-center" style="margin-top:40px;">
        <div style="text-align:center;">
            <div class="upload-icon">
                <svg width="48" height="48" fill="none" viewBox="0 0 48 48"><rect width="48" height="48" rx="12" fill="#2563eb"/><path d="M24 34V14M24 14l-7 7m7-7l7 7" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </div>
            <h2 style="margin-bottom:8px;">Upload Dokumen</h2>
            <div style="color:#64748b;font-size:1em;margin-bottom:18px;">Unggah file dokumen Anda ke E-Dokumen</div>
        </div>
        <?php if ($pesan): ?>
            <div class="<?= $success ? 'success' : 'error' ?>"><?= htmlspecialchars($pesan) ?></div>
        <?php endif; ?>
        <form method="post" enctype="multipart/form-data" id="uploadForm" autocomplete="off">
            <label>Judul Dokumen</label>
            <input type="text" name="judul" required style="width:100%;max-width:400px;">
            <label>Deskripsi</label>
            <textarea name="deskripsi" placeholder="Opsional" style="width:100%;max-width:400px;"></textarea>
            <label>Kategori</label>
            <input type="text" name="kategori" placeholder="Opsional" style="width:100%;max-width:400px;">
            <label>Pilih File</label>
            <div class="file-input-wrapper" style="max-width:400px;width:100%;">
                <label for="fileInput" class="custom-file-label" style="width:100%;box-sizing:border-box;">
                    <svg width="20" height="20" style="vertical-align:middle;margin-right:6px;" fill="none" viewBox="0 0 24 24"><rect width="24" height="24" rx="6" fill="#2563eb"/><path d="M12 16v-8m0 0-3 3m3-3 3 3" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    <span id="fileLabelText">Pilih file dokumen...</span>
                </label>
                <input type="file" name="file" id="fileInput" required style="display:none;">
                <span id="fileName" class="file-name-preview">Belum ada file dipilih</span>
            </div>
            <button type="submit" class="btn-utama" style="margin-top:10px;max-width:400px;width:100%;">Upload</button>
        </form>
        <div style="margin-top:18px;">
            <a href="dashboard.php" style="color:#2563eb;text-decoration:underline;">&#8592; Kembali ke Dashboard</a>
        </div>
    </div>
    <footer>
        &copy; <?= date('Y') ?> E-Dokumen | Dibuat oleh Zhafran
    </footer>
    <script>
    document.getElementById('fileInput').addEventListener('change', function() {
        var fileName = this.files[0] ? this.files[0].name : 'Belum ada file dipilih';
        document.getElementById('fileName').textContent = fileName;
        document.getElementById('fileLabelText').textContent = this.files[0] ? this.files[0].name : 'Pilih file dokumen...';
    });
    document.querySelector('.custom-file-label').addEventListener('click', function() {
        document.getElementById('fileInput').click();
    });
    </script>
</body>
</html>
